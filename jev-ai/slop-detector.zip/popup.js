const apiKey = document.getElementById("apiKey");
const toggleKey = document.getElementById("toggleKey");
const save = document.getElementById("save");
const test = document.getElementById("test");
const enabled = document.getElementById("enabled");
const threshold = document.getElementById("threshold");
const thresholdValue = document.getElementById("thresholdValue");
const status = document.getElementById("status");
const resetStats = document.getElementById("resetStats");

function showStatus(message, ok) {
  status.hidden = false;
  status.textContent = message;
  status.className = `status ${ok ? "ok" : "bad"}`;
}

function renderStats(stats) {
  document.getElementById("statWorth").textContent = stats?.worth || 0;
  document.getElementById("statMixed").textContent = stats?.mixed || 0;
  document.getElementById("statSkip").textContent = stats?.skip || 0;
}

async function load() {
  const settings = await chrome.runtime.sendMessage({ type: "settings" });
  apiKey.value = settings.jevApiKey || "";
  enabled.checked = settings.enabled !== false;
  threshold.value = settings.threshold ?? 0.55;
  thresholdValue.textContent = Number(threshold.value).toFixed(2);
  renderStats(settings.stats);
  if (!settings.jevApiKey) {
    showStatus("Paste a Jev API key to start detecting slop.", false);
  }
}

save.addEventListener("click", async () => {
  await chrome.storage.local.set({ jevApiKey: apiKey.value.trim() });
  showStatus("Key saved on this Chrome profile.", true);
});

test.addEventListener("click", async () => {
  showStatus("Talking to Jev…", true);
  const result = await chrome.runtime.sendMessage({ type: "test-key", apiKey: apiKey.value });
  if (result?.ok) {
    showStatus(`Connected via ${result.provider}. Model ${result.model}.`, true);
  } else {
    showStatus(result?.message || "Could not reach Jev.", false);
  }
});

enabled.addEventListener("change", async () => {
  await chrome.storage.local.set({ enabled: enabled.checked });
});

threshold.addEventListener("input", () => {
  thresholdValue.textContent = Number(threshold.value).toFixed(2);
});

threshold.addEventListener("change", async () => {
  await chrome.storage.local.set({ threshold: Number(threshold.value) });
});

toggleKey.addEventListener("click", () => {
  const hidden = apiKey.type === "password";
  apiKey.type = hidden ? "text" : "password";
  toggleKey.textContent = hidden ? "Hide" : "Show";
});

resetStats.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "reset-stats" });
  renderStats({ worth: 0, mixed: 0, skip: 0 });
});

load().catch((error) => showStatus(String(error.message || error), false));

const DEFAULTS = {
  jevApiKey: "",
  enabled: true,
  threshold: 0.55,
  stats: { worth: 0, mixed: 0, skip: 0 },
};

const QUESTIONS = {
  worth_reading: {
    type: "noul",
    instructions:
      "Would a careful reader gain specific, non-obvious information from this content that is worth their time?",
    criteria: {
      true: "Editorial or personal information: reporting, explanation, first-hand detail, or a real argument with specifics. Not a sale.",
      false: "An ad, a sponsored pitch, or thin / vague content with no substance.",
    },
  },
  ai_slop: {
    type: "noul",
    instructions:
      "Is this AI slop or otherwise low-signal filler dressed up as information?",
    criteria: {
      true: "Generic LLM cadence, buzzword stacking, empty listicles, engagement bait, recycled takes, or content that sounds smart but says nothing.",
      false: "Specific, grounded, and not obviously machine-generated filler.",
    },
  },
  is_ad: {
    type: "noul",
    instructions:
      "Is this an advertisement, sponsored post, or a sales pitch trying to get the reader to buy, sign up, or click?",
    criteria: {
      true: "Promoted or sponsored content, an ad unit, or marketing copy selling a product, plan, course, app, or waitlist.",
      false: "Ordinary editorial content, news, or a person's own post, even if a product is mentioned in passing.",
    },
  },
};

const cache = new Map();
const inflight = new Map();
let queue = [];
let active = 0;
const MAX_ACTIVE = 3;
const MAX_CACHE = 400;

function detectProvider(apiKey) {
  const key = (apiKey || "").trim();
  if (key.startsWith("vck_")) {
    return {
      id: "vercel",
      endpoint: "https://ai-gateway.vercel.sh/typesafe/v1/systemone",
      model: "typesafe-ai/jev",
    };
  }
  if (key.startsWith("sk-or-")) {
    return {
      id: "openrouter",
      endpoint: "https://openrouter.ai/api/alpha/decisions",
      model: "typesafe/jev-1.13",
    };
  }
  return {
    id: "typesafe",
    endpoint: "https://api.typesafe.ai/v1/systemone",
    model: "jev-latest",
  };
}

async function getSettings() {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULTS));
  return { ...DEFAULTS, ...stored };
}

async function setBadge(verdict) {
  const map = {
    worth: { text: "OK", color: "#178A4B" },
    mixed: { text: "MIX", color: "#B8860B" },
    skip: { text: "SLOP", color: "#B42336" },
    pending: { text: "…", color: "#445048" },
    idle: { text: "", color: "#445048" },
    error: { text: "!", color: "#B42336" },
  };
  const spec = map[verdict] || map.idle;
  await chrome.action.setBadgeText({ text: spec.text });
  await chrome.action.setBadgeBackgroundColor({ color: spec.color });
}

function noulOf(answer) {
  if (!answer) return 0;
  return Number(answer.noul ?? answer.probability ?? 0);
}

function decide(worth, slop, ad, threshold) {
  if (ad >= 0.55) return "skip";
  if (slop >= 0.68 && slop > worth) return "skip";
  if (worth >= threshold && slop < 0.45) return "worth";
  if (worth < 0.4 || slop >= 0.7) return "skip";
  return "mixed";
}

function cacheKey(item) {
  const text = (item.text || "").slice(0, 1800);
  return `v2:${item.kind || "unit"}:${item.id || ""}:${text}`;
}

function remember(key, value) {
  cache.set(key, value);
  if (cache.size > MAX_CACHE) {
    const first = cache.keys().next().value;
    cache.delete(first);
  }
}

async function bumpStat(verdict) {
  if (!["worth", "mixed", "skip"].includes(verdict)) return;
  const settings = await getSettings();
  const stats = { ...DEFAULTS.stats, ...(settings.stats || {}) };
  stats[verdict] = (stats[verdict] || 0) + 1;
  await chrome.storage.local.set({ stats });
}

async function callJev(apiKey, state) {
  const provider = detectProvider(apiKey);
  const headers = {
    Authorization: `Bearer ${apiKey}`,
    "Content-Type": "application/json",
  };
  if (provider.id === "openrouter") {
    headers["HTTP-Referer"] = "https://github.com/local/jev-signal";
    headers["X-Title"] = "Slop Detector";
  }
  const response = await fetch(provider.endpoint, {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: provider.model,
      state,
      questions: QUESTIONS,
    }),
  });
  const text = await response.text();
  if (!response.ok) {
    throw new Error(`Jev HTTP ${response.status}: ${text.slice(0, 280)}`);
  }
  return JSON.parse(text);
}

async function scoreItem(item) {
  const settings = await getSettings();
  if (!settings.enabled) {
    return { ok: false, reason: "disabled" };
  }
  const apiKey = (settings.jevApiKey || "").trim();
  if (!apiKey) {
    return { ok: false, reason: "missing_key" };
  }

  const key = cacheKey(item);
  if (cache.has(key)) return cache.get(key);
  if (inflight.has(key)) return inflight.get(key);

  const work = (async () => {
    if (item.markedAd) {
      const result = { ok: true, worth: 0, slop: 1, ad: 1, verdict: "skip", model: "", provider: "local" };
      remember(key, result);
      await bumpStat("skip");
      return result;
    }
    const state = {
      source: item.source || "",
      kind: item.kind || "unit",
      url: item.url || "",
      title: item.title || "",
      author: item.author || "",
      text: (item.text || "").slice(0, 4000),
    };
    const data = await callJev(apiKey, state);
    const answers = data.answers || {};
    const worth = noulOf(answers.worth_reading);
    const slop = noulOf(answers.ai_slop);
    const ad = noulOf(answers.is_ad);
    const verdict = decide(worth, slop, ad, Number(settings.threshold) || 0.55);
    const result = {
      ok: true,
      worth,
      slop,
      ad,
      verdict,
      model: data.model || "",
      provider: detectProvider(apiKey).id,
    };
    remember(key, result);
    await bumpStat(verdict);
    return result;
  })();

  inflight.set(key, work);
  try {
    return await work;
  } finally {
    inflight.delete(key);
  }
}

function enqueue(item, respond) {
  queue.push({ item, respond });
  pump();
}

async function pump() {
  while (active < MAX_ACTIVE && queue.length) {
    const job = queue.shift();
    active += 1;
    scoreItem(job.item)
      .then(job.respond)
      .catch((error) => {
        job.respond({ ok: false, reason: "error", message: String(error.message || error) });
      })
      .finally(() => {
        active -= 1;
        pump();
      });
  }
}

async function testKey(apiKey) {
  const key = (apiKey || "").trim();
  if (!key) return { ok: false, message: "Paste a Jev API key first." };
  const data = await callJev(key, {
    kind: "self_test",
    text: "CERN measured the Higgs boson mass at 125 GeV using ATLAS and CMS collision data.",
  });
  const worth = noulOf(data.answers && data.answers.worth_reading);
  return {
    ok: true,
    provider: detectProvider(key).id,
    model: data.model || detectProvider(key).model,
    worth,
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "score") {
    enqueue(message.item, sendResponse);
    return true;
  }
  if (message?.type === "hud") {
    setBadge(message.verdict || "idle");
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === "settings") {
    getSettings().then(sendResponse);
    return true;
  }
  if (message?.type === "test-key") {
    testKey(message.apiKey)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, message: String(error.message || error) }));
    return true;
  }
  if (message?.type === "reset-stats") {
    chrome.storage.local.set({ stats: DEFAULTS.stats }).then(() => sendResponse({ ok: true }));
    return true;
  }
  return false;
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "toggle-signal") return;
  const settings = await getSettings();
  await chrome.storage.local.set({ enabled: !settings.enabled });
});

chrome.runtime.onInstalled.addListener(() => {
  setBadge("idle");
});

const SKIP_HOSTS = new Set([
  "chrome.google.com",
  "chromewebstore.google.com",
]);

const MIN_CHARS = {
  post: 40,
  article: 80,
  section: 60,
  headline: 40,
};

let settings = {
  jevApiKey: "",
  enabled: true,
  threshold: 0.55,
};
let scored = new WeakMap();
let observer = null;
let visibility = null;
let navTimer = 0;
let lastHref = location.href;
let hud = null;
let scanTimer = 0;

function $(sel, root = document) {
  return root.querySelector(sel);
}

function $all(sel, root = document) {
  return [...root.querySelectorAll(sel)];
}

function cleanText(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim();
}

function host() {
  return location.hostname.replace(/^www\./, "");
}

function isX() {
  const h = host();
  return h === "x.com" || h === "twitter.com";
}

function isHN() {
  return host() === "news.ycombinator.com";
}

function isReddit() {
  return host() === "reddit.com" || host().endsWith(".reddit.com");
}

function unitId(kind, el, text) {
  const attr =
    el.getAttribute("data-jev-id") ||
    el.getAttribute("data-testid") ||
    el.id ||
    "";
  const href = el.querySelector?.("a[href*='/status/']")?.href || el.href || "";
  const slice = cleanText(text).slice(0, 80);
  return `${kind}:${attr}:${href}:${slice}`;
}

function extractFrom(el) {
  if (!el) return "";
  const clone = el.cloneNode(true);
  $all(
    "script, style, noscript, svg, nav, button, form, .jev-demo-note, .jev-demo-expect",
    clone
  ).forEach((node) => node.remove());
  return cleanText(clone.innerText || clone.textContent || "");
}

const AD_SELECTORS = [
  "ins.adsbygoogle",
  "[id^='google_ads']",
  "[id*='div-gpt-ad']",
  "[data-google-query-id]",
  "[aria-label='Advertisement']",
  "[aria-label='Promoted']",
  "[data-testid='placementTracking']",
  "iframe[src*='doubleclick']",
  "iframe[src*='googlesyndication']",
];

function isAdElement(el) {
  if (!el || el.nodeType !== 1) return false;
  if (el.getAttribute("data-jev-ad") === "true") return true;
  try {
    if (AD_SELECTORS.some((sel) => el.matches(sel) || el.querySelector(sel) || el.closest(sel))) {
      return true;
    }
  } catch (_err) {
    // invalid selector on this node
  }
  const social = cleanText($( '[data-testid="socialContext"]', el )?.innerText || "");
  if (/promoted|sponsored/i.test(social)) return true;
  const labeled = [...el.querySelectorAll("span, a")].some((node) => {
    const text = cleanText(node.textContent);
    return text === "Ad" || text === "Promoted" || text === "Sponsored";
  });
  return labeled;
}

function tagUnit(unit) {
  return { ...unit, markedAd: isAdElement(unit.el) };
}

function markedUnits() {
  const marked = $all("[data-jev-unit]");
  if (!marked.length) return [];
  return marked
    .map((el) => {
      const kind = el.getAttribute("data-jev-kind") || "section";
      const title = cleanText(
        $("h1, h2, h3", el)?.innerText || el.getAttribute("data-jev-title") || ""
      );
      const text = extractFrom(el);
      return {
        el,
        kind,
        id: unitId(kind, el, text),
        title,
        author: cleanText(el.getAttribute("data-jev-author") || ""),
        url: location.href,
        text,
        source: host(),
      };
    })
    .filter((unit) => unit.text.length >= (MIN_CHARS[unit.kind] || 40));
}

function feedUnits() {
  const articles = $all("article").filter((el) => extractFrom(el).length >= MIN_CHARS.post);
  if (articles.length < 3) return [];
  return articles.map((el) => {
    const title = cleanText($("h1, h2, h3", el)?.innerText || "");
    const text = extractFrom(el);
    return {
      el,
      kind: "post",
      id: unitId("post", el, text),
      title,
      author: cleanText($('[rel="author"], .author', el)?.innerText || ""),
      url: location.href,
      text: text.slice(0, 4000),
      source: host(),
    };
  });
}

function tweetUnits() {
  return $all('article[data-testid="tweet"]').map((el) => {
    const textEl = $('[data-testid="tweetText"]', el);
    const text = extractFrom(textEl) || extractFrom(el);
    const author = cleanText($('[data-testid="User-Name"]', el)?.innerText || "");
    const link = $("a[href*='/status/']", el);
    return {
      el,
      kind: "post",
      id: unitId("post", el, text),
      title: "",
      author,
      url: link ? link.href : location.href,
      text,
      source: host(),
    };
  });
}

function hnUnits() {
  return $all("tr.athing").map((row) => {
    const title = cleanText($(".titleline", row)?.innerText || "");
    const link = $(".titleline a", row);
    return {
      el: row,
      kind: "headline",
      id: unitId("headline", row, title),
      title,
      author: "",
      url: link ? link.href : location.href,
      text: title,
      source: host(),
    };
  });
}

function redditUnits() {
  const posts = $all('shreddit-post, [data-testid="post-container"], article');
  return posts
    .map((el) => {
      const title = cleanText(
        el.getAttribute?.("post-title") ||
          $("h1, h2, [slot='title'], [id$='-post-rtjson-content']", el)?.innerText ||
          ""
      );
      const body = extractFrom($("[id$='-post-rtjson-content'], [data-click-id='text']", el) || el);
      const text = [title, body].filter(Boolean).join("\n");
      return {
        el,
        kind: "post",
        id: unitId("post", el, text),
        title,
        author: "",
        url: location.href,
        text,
        source: host(),
      };
    })
    .filter((unit) => unit.text.length >= MIN_CHARS.post);
}

function articleRoot() {
  return (
    $("article") ||
    $('[role="main"]') ||
    $("main") ||
    $(".post-body, .entry-content, .article-body, .story-body") ||
    document.body
  );
}

function articleUnits() {
  const root = articleRoot();
  if (!root || root === document.body && document.body.innerText.length < 400) {
    return [];
  }

  const title = cleanText($("h1")?.innerText || document.title);
  const headings = $all("h1, h2, h3", root);
  const units = [];

  if (title) {
    const lead = $all("p", root)
      .slice(0, 6)
      .map((p) => extractFrom(p))
      .filter(Boolean)
      .join("\n");
    units.push({
      el: $("h1") || root,
      kind: "article",
      id: unitId("article", root, title),
      title,
      author: cleanText($('[rel="author"], .author, [itemprop="author"]')?.innerText || ""),
      url: location.href,
      text: `${title}\n${lead}`.slice(0, 4000),
      source: host(),
    });
  }

  if (headings.length >= 2) {
    headings.forEach((heading, index) => {
      const bits = [extractFrom(heading)];
      let node = heading.nextElementSibling;
      let guard = 0;
      while (node && !/^H[1-3]$/.test(node.tagName) && guard < 12) {
        if (["P", "UL", "OL", "BLOCKQUOTE", "PRE"].includes(node.tagName)) {
          bits.push(extractFrom(node));
        }
        node = node.nextElementSibling;
        guard += 1;
      }
      const text = bits.filter(Boolean).join("\n");
      if (text.length < MIN_CHARS.section) return;
      units.push({
        el: heading,
        kind: "section",
        id: unitId("section", heading, text + String(index)),
        title: extractFrom(heading),
        author: "",
        url: location.href,
        text,
        source: host(),
      });
    });
  } else {
    const paras = $all("p", root).filter((p) => extractFrom(p).length > 80);
    for (let i = 0; i < paras.length; i += 3) {
      const group = paras.slice(i, i + 3);
      const text = group.map(extractFrom).join("\n");
      if (text.length < MIN_CHARS.section) continue;
      units.push({
        el: group[0],
        kind: "section",
        id: unitId("section", group[0], text),
        title,
        author: "",
        url: location.href,
        text,
        source: host(),
      });
    }
  }

  return units;
}

function collectUnits() {
  let units = markedUnits();
  if (!units.length) {
    if (isX()) units = tweetUnits();
    else if (isHN()) units = hnUnits();
    else if (isReddit()) units = redditUnits();
    else {
      const feed = feedUnits();
      units = feed.length ? feed : articleUnits();
    }
  }
  return units.map(tagUnit);
}

function ensureHud() {
  if (hud) return hud;
  hud = document.createElement("div");
  hud.id = "jev-sig-root";
  hud.innerHTML = `
    <div class="jev-sig-edge" aria-hidden="true"></div>
    <aside class="jev-sig-chip" role="status">
      <div class="jev-sig-chip-top">
        <span class="jev-sig-dot"></span>
        <strong class="jev-sig-label">Slop Detector</strong>
      </div>
      <p class="jev-sig-meta">Add a Jev API key in the popup to start checking pages as you scroll.</p>
    </aside>
  `;
  document.documentElement.appendChild(hud);
  return hud;
}

function paintHud(verdict, meta) {
  ensureHud();
  const edge = hud.querySelector(".jev-sig-edge");
  const label = hud.querySelector(".jev-sig-label");
  const metaEl = hud.querySelector(".jev-sig-meta");
  const copy = {
    worth: "Worth it",
    mixed: "Mixed",
    skip: "Slop",
    pending: "Checking for slop…",
    missing_key: "API key needed",
    disabled: "Slop Detector is off",
    error: "Could not score this",
    idle: "Scroll to check",
  };
  edge.className = `jev-sig-edge jev-${verdict}`;
  hud.querySelector(".jev-sig-chip").className = `jev-sig-chip jev-${verdict}`;
  label.textContent = copy[verdict] || copy.idle;
  metaEl.textContent = meta || "";
  chrome.runtime.sendMessage({ type: "hud", verdict }).catch(() => {});
}

function paintUnit(el, verdict) {
  el.classList.add("jev-sig-unit");
  el.classList.remove("jev-worth", "jev-mixed", "jev-skip", "jev-pending", "jev-error");
  el.classList.add(`jev-${verdict}`);
  el.setAttribute("data-jev-verdict", verdict);

  const skipFrame = ["TR", "TD", "TH", "H1", "H2", "H3"].includes(el.tagName);
  if (skipFrame) return;

  let frame = el.querySelector(":scope > .jev-sig-frame");
  if (!frame) {
    frame = document.createElement("span");
    frame.setAttribute("aria-hidden", "true");
    el.insertBefore(frame, el.firstChild);
  }
  frame.className = `jev-sig-frame jev-${verdict}`;
}

function visibleRatio(el) {
  const rect = el.getBoundingClientRect();
  const h = Math.min(rect.bottom, window.innerHeight) - Math.max(rect.top, 0);
  if (rect.height <= 0) return 0;
  return Math.max(0, h) / rect.height;
}

function mostVisibleScored() {
  let best = null;
  let bestRatio = 0.18;
  collectUnits().forEach((unit) => {
    const result = scored.get(unit.el);
    if (!result || !result.ok) return;
    const ratio = visibleRatio(unit.el);
    if (ratio > bestRatio) {
      best = { unit, result, ratio };
      bestRatio = ratio;
    }
  });
  return best;
}

function formatMeta(result) {
  const worth = Math.round((result.worth || 0) * 100);
  const slop = Math.round((result.slop || 0) * 100);
  return `slop ${slop}% · worth ${worth}%`;
}

function refreshHud() {
  if (!settings.enabled) {
    paintHud("disabled", "Turn it back on from the Slop Detector popup, or press Alt+J.");
    return;
  }
  if (!settings.jevApiKey) {
    paintHud("missing_key", "Open the toolbar icon and paste your Jev API key.");
    return;
  }
  const current = mostVisibleScored();
  if (current) {
    paintHud(current.result.verdict, formatMeta(current.result));
    return;
  }
  const pending = collectUnits().some((unit) => unit.el.classList.contains("jev-pending"));
  paintHud(pending ? "pending" : "idle", pending ? "Checking this page." : "Keep scrolling. Visible posts and articles get a slop check.");
}

function score(unit) {
  const min = MIN_CHARS[unit.kind] || 50;
  if (!unit.text || unit.text.length < min) return;
  if (!settings.jevApiKey) {
    refreshHud();
    return;
  }
  if (scored.has(unit.el)) {
    const existing = scored.get(unit.el);
    if (existing?.ok) paintUnit(unit.el, existing.verdict);
    return;
  }
  scored.set(unit.el, { ok: false, pending: true });
  paintUnit(unit.el, "pending");
  const { el, ...item } = unit;
  chrome.runtime.sendMessage({ type: "score", item }, (result) => {
    if (chrome.runtime.lastError) {
      scored.delete(unit.el);
      paintUnit(unit.el, "error");
      refreshHud();
      return;
    }
    if (!result?.ok) {
      if (result?.reason === "missing_key") {
        paintHud("missing_key", "Open the toolbar icon and paste a Jev API key.");
      } else if (result?.reason === "error") {
        scored.delete(unit.el);
        paintUnit(unit.el, "error");
        paintHud("error", result.message || "Request failed.");
      }
      refreshHud();
      return;
    }
    scored.set(unit.el, result);
    paintUnit(unit.el, result.verdict);
    refreshHud();
  });
}

function scan() {
  if (!settings.enabled) return;
  const units = collectUnits();
  units.forEach((unit) => {
    if (!visibility) return;
    visibility.observe(unit.el);
    if (visibleRatio(unit.el) > 0.08) score(unit);
  });
  refreshHud();
}

function scheduleScan() {
  clearTimeout(scanTimer);
  scanTimer = setTimeout(scan, 180);
}

function start() {
  if (SKIP_HOSTS.has(host())) return;
  ensureHud();
  if (visibility) visibility.disconnect();
  visibility = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const unit = collectUnits().find((item) => item.el === entry.target);
        if (unit) score(unit);
      });
      refreshHud();
    },
    { root: null, threshold: [0.15, 0.35, 0.6], rootMargin: "80px 0px" }
  );

  if (observer) observer.disconnect();
  observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  scan();
}

function stop() {
  observer?.disconnect();
  visibility?.disconnect();
  observer = null;
  visibility = null;
  $all(".jev-sig-frame").forEach((el) => el.remove());
  $all(".jev-sig-unit").forEach((el) => {
    el.classList.remove("jev-sig-unit", "jev-worth", "jev-mixed", "jev-skip", "jev-pending", "jev-error");
    el.removeAttribute("data-jev-verdict");
  });
  refreshHud();
}

async function loadSettings() {
  settings = await chrome.runtime.sendMessage({ type: "settings" });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.threshold) settings.threshold = changes.threshold.newValue;
  if (changes.jevApiKey) {
    settings.jevApiKey = changes.jevApiKey.newValue || "";
    scored = new WeakMap();
    $all(".jev-sig-frame").forEach((el) => el.remove());
    $all(".jev-sig-unit").forEach((el) => {
      el.classList.remove("jev-sig-unit", "jev-worth", "jev-mixed", "jev-skip", "jev-pending", "jev-error");
      el.removeAttribute("data-jev-verdict");
    });
    if (settings.enabled) scheduleScan();
  }
  if (changes.enabled) {
    settings.enabled = changes.enabled.newValue;
    if (settings.enabled) start();
    else stop();
  }
  refreshHud();
});

window.addEventListener("scroll", () => refreshHud(), { passive: true });

navTimer = window.setInterval(() => {
  if (location.href === lastHref) return;
  lastHref = location.href;
  scored = new WeakMap();
  scheduleScan();
}, 800);

loadSettings()
  .then(() => {
    if (settings.enabled) start();
    else {
      ensureHud();
      refreshHud();
    }
  })
  .catch(() => {
    ensureHud();
    paintHud("error", "Could not reach Slop Detector. Reload the extension.");
  });
